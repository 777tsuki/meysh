<div class="whole">
  
<div>
  <img class="blank1" src="source/icon/blank.png" width="44" height="44">
  <div class="navbar">
    <img class="blank0" src="source/icon/blank.png" width="44px" height="30">
    <a class="navbarbotton" href="index.php">甲板</a>
    <a class="navbarbotton" href="courselist.php">海图</a>
    <a class="navbarbotton" href="forum.php">酒馆</a>
    <a class="navbarbotton" href="user.php" style="float:right;">吊床</a>
  </div>
</div>
<div class="row">
  <img class="blank1" src="source/icon/blank.png" width="44" height="800">
  <div class="main">
    <h1 style="text-align: center;">BTの窝</h1>
    <form class="login" action="user?link=message" method="post">
      <h2>登录</h2><hr/><br>
      <a>邮箱  </a><input type="text" name="mail" class="import"><br><br>
      <a>密码  </a><input type="password" name="password" class="import"><br><br>
      <input type="submit" value="LOGIN" class="clickbotton"><p></p>
    </form><br>
    <div class="others">
      <a class="otherleft" href="../../user?link=forgetpassword" style="text-decoration:none;"><h2>忘记密码</h2></a>
      <a class="otherright" href="../../user?link=register" style="text-decoration:none;"><h2>注册</h2></a>
    </div>
  </div>
</div>
<div class="footer">
  <h2>敬请期待</h2>
</div>
</div>